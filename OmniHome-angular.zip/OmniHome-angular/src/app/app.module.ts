import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModules, Routes } from '@angular/router';
import { routes } from './app.router';

import { AppComponent } from './app.component';
import { headerComponent } from './header-component/header.component';
import { footerComponent } from './footer-component/footer.component';
import { mainComponent } from './main-component/main.component';
import { profileComponent } from './profile-component/profile.component';

@NgModule({
  declarations: [
    AppComponent,
    headerComponent,
    footerComponent,
    mainComponent,
    profileComponent
  ],
  imports: [
    BrowserModule,
      FormsModule,
      HttpModule,
      routes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
