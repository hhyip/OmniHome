import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import { AppComponent} from './app.component';
import { profileComponent} from './profile-component/profile.component';     
import { headerComponent} from './header-component/header.component';
import { footerComponent} from './footer-component/footer.component';
import { mainComponent} from './main-component/main.component';
import { loginComponent} from './login-component/login.component';
export const router: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

     { path: 'header', component: headerComponent },
     { path: 'footer', component: footerComponent },
    { path: 'profile', component: profileComponent }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);

