import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
//import { RouterModules } from '@angular/router';
import { AppComponent } from './app.component';

import { HttpModule } from '@angular/http';
import { routes } from './app.router';


import { headerComponent } from './header-component/header.component';
import { footerComponent } from './footer-component/footer.component';
import { mainComponent } from './main-component/main.component';
import { profileComponent } from './profile-component/profile.component';
import { loginComponent } from './login-component/login.component';
const appRoutes: Routes = [
     { path: 'login', component: loginComponent },
     { path: 'main', component: mainComponent },
       { path: 'profile', component: profileComponent }
]

@NgModule({
  declarations: [
    AppComponent,
    headerComponent,
    footerComponent,
    mainComponent,
    profileComponent,
      loginComponent
  ],
    
    
  imports: [
    BrowserModule,
      FormsModule,
      HttpModule,
      routes
      //RouterModule.forRoot(
      //appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
