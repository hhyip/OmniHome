import { Component, OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common/common.service';
import { ToDoItem } from '../shopListEx/shopListEx.model';

@Component({
  selector: 'shopList',
  templateUrl: './shopList.component.html',
  styleUrls: ['./shopList.component.css']
})
export class shopListComponent implements OnInit {
    
    private shopList:listItem[]

    constructor(private commonService:CommonService) {

    }

    ngOnInit(){
        
        this.getAllListItems()
        
        this.commonService.add_subject.subscribe(response => {
            this.getAllListItems()
        })
        
    }
    
    getAllToDoItems(){
        this.commonService.getList().subscribe(res =>{
            this.toDoList = []
            res.json().data.map(e =>{
                this.shopList.push(new ListItem(e.item,false));
            })
        })
    }
    
}