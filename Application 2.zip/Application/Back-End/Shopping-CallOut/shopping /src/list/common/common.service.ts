import { Injectable } from '@angular/core';
import { ShopList } from '../shopList/shopListEx.model';
import { Subject } from 'rxjs/Subject';
import { Http } from '@angular/http';
import {Observable} from 'rxjs';

@Injectable()
export class CommonService {
    public shopList: shopList[]
    public add_subject=new Subject<String>()

    constructor(private http : Http){
        this.shopList = []
    }

    addToDo(item){
        return this.http.post('/api/addList',{
            shopItem : item
        })
    }
    
    getToDo(){
        return this.http.post('/api/getList',{})
    }
} 