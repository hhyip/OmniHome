var express = require('express')
var bodyParser = require('body-parser')
var toDoService  = require('./services/shopService')
var app = express()

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended : false}))

app.post('/api/addShopList', function (req, res) {
  let shopServiceObj = new shopService(req, res)
  toDoServiceObj.addList()
})

app.post('/api/getList', function (req, res) {
  let shopServiceObj = new shopService(req, res)
  listServiceObj.getlist()
})

app.listen(3000, function () {
  console.log('To Do Web app service listening on port 3000!')
})