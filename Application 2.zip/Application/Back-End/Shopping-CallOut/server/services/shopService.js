var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var url = 'mongodb://localhost:27017/shopList';

class shopService{
    
    constructor(req, res){
        this.req = req
        this.res = res
    }
    
    insert(shopItem, db, callback){
        db.collection('shopItems').insertOne({
            "item" : shopItem
        }, function(){
            callback()
        })
    }
    
    addshop(){
        let self = this;
        let shopItem = this.req.body.shopItem;
        try{
            MongoClient.connect(url, function(err, db) {
                assert.equal(null, err);
                self.insert(shopItem, db, function(){
                    db.close()
                    return self.res.status(200).json({
                        status : 'success'
                    })
                })
            });
        }
        catch(error){
            return self.res.status(500).json({
                status : 'error',
                error : error
            })
        }
    }
    
    getshop(){
        let self = this;
        try{
            MongoClient.connect(url, function(err, db){
                assert.equal(null, err);
                let shopList = []
                let cursor = db.collection('shopItems').find();
                
                cursor.each(function(err, doc) {
                    assert.equal(err, null);
                    if (doc != null) {
                        shopList.push(doc)
                    } else {
                        return self.res.status(200).json({
                            status : 'success',
                            data : shopList
                        })
                    }
                });
            });
        }
        catch(error){
            return self.res.status(500).json({
                status : 'error',
                error : error
            })
        }
    }
}
module.exports = shopService