import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import { AppComponent} from './app.component';
import { profileComponent} from './profile-component/profile.component';     
import { headerComponent} from './header-component/header.component';
import { footerComponent} from './footer-component/footer.component';
import { mainComponent} from './main-component/main.component';
import { leaderboardComponent} from './leaderboard-component/leaderboard.component';
import { calloutComponent } from './callout-component/callout.component';
import { frontpageComponent } from './frontpage-component/frontpage.component';
import { settingsComponent } from './settings-component/settings.component';
import { choreComponent } from './chore-component/chore.component';
import { shoppingListComponent } from './shoppinglist-component/shoppinglist.component';

export const router: Routes = [
  { path: '', redirectTo: 'main', pathMatch: 'full' },
  { path: 'main', component: mainComponent },
  { path: 'header', component: headerComponent },
  { path: 'footer', component: footerComponent },
  { path: 'profile', component: profileComponent },
  { path: 'leaderboard', component: leaderboardComponent },    
  { path: 'callout', component: calloutComponent },
  { path: 'frontpage', component: frontpageComponent },
  { path: 'settings', component: settingsComponent },
  { path: 'chore', component: choreComponent },
  { path: 'shoppinglist', component: shoppingListComponent }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);

