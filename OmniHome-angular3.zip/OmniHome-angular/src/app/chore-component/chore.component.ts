import { Component } from '@angular/core';

@Component({
  selector: 'app-chore',
  templateUrl: './chore.component.html',
  styleUrls: ['./chore.component.css']
})
export class choreComponent {
  title = 'app';
}