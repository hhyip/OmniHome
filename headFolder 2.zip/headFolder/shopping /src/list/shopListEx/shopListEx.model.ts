export class ToDoItem {
	constructor(
		public Name: String,
		public IsDone: Boolean
	) { }
}