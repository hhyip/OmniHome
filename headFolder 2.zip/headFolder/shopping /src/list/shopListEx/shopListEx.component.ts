import { Component, OnInit } from '@angular/core';
import { shopList } from './shopList.model';
import { CommonService } from '../common/common.service';

@Component({
    selector: 'shopList-add',
    templateUrl: './shopListEx.component.html',
    styleUrls: ['./shopLiseEx.component.css']

})
export class shopListExComponent implements OnInit {

    private shopListItem


    constructor(private commonService:CommonService) {

    }

    addToDo(){
        this.commonService.addList(this.listItem).subscribe(res => {
            this.commonService.add_subject.next()
        })
        
		this.listItem = ''
    }

    ngOnInit() {

    }
}