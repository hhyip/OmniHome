import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { listComponent } from './list.component';
import { shopListExComponent } from './toDoListAdd/toDoListAdd.component';
import { shopListComponent } from './toDoList/shopList.component';
import { CommonService } from './common/common.service';

@NgModule({
  declarations: [
    listComponent,
    shopListExComponent,
    shopListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [CommonService],
  bootstrap: [listComponent]
})
export class AppModule { }
 