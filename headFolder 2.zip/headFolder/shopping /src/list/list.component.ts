bgimport { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class AppComponent {
  title = 'app';
}